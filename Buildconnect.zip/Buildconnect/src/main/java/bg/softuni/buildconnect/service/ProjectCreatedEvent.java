package bg.softuni.buildconnect.service;

import org.springframework.context.ApplicationEvent;

public class ProjectCreatedEvent extends ApplicationEvent {

    private final Long projectId;
    private final String creatorUsername;

    public ProjectCreatedEvent(Object source, Long projectId, String creatorUsername) {
        super(source);
        this.projectId = projectId;
        this.creatorUsername = creatorUsername;
    }

    public Long getProjectId() {
        return projectId;
    }

    public String getCreatorUsername() {
        return creatorUsername;
    }
}
