package bg.softuni.buildconnect.service;

import bg.softuni.buildconnect.dto.DocumentDTO;

import java.util.List;
import java.util.Optional;

public interface DocumentService {

    List<DocumentDTO> getAllDocuments();

    Optional<DocumentDTO> getDocumentById(Long id);

    void saveDocument(DocumentDTO documentDTO);

    void deleteDocument(Long id);
}
