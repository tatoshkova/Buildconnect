
package bg.softuni.buildconnect.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ScheduledTasks {

    private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);

    // Всеки ден в 08:00 ч.
    @Scheduled(cron = "0 0 8 * * *")
    public void dailyReminderTask() {
        logger.info("🕗 Daily reminder executed at 8:00 AM!");
        // TODO: Add real logic, e.g. email reminders or cleanup
    }
}
