package bg.softuni.buildconnect.service;

import bg.softuni.buildconnect.dto.ProjectDTO;

import java.util.List;
import java.util.Optional;

public interface ProjectService {

    List<ProjectDTO> getAllProjects();

    Optional<ProjectDTO> getProjectById(Long id);

    void createProject(ProjectDTO projectDTO);

    void updateProject(Long id, ProjectDTO projectDTO);

    void deleteProject(Long id);

    long countAllProjects();
}
