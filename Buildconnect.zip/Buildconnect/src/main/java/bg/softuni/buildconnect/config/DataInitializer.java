package bg.softuni.buildconnect.config;

import bg.softuni.buildconnect.entity.Role;
import bg.softuni.buildconnect.repository.RoleRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer {

    private final RoleRepository roleRepository;

    public DataInitializer(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @PostConstruct
    public void init() {
        roleRepository.findByName("USER")
                .orElseGet(() -> roleRepository.save(new Role("USER")));

        roleRepository.findByName("ADMIN")
                .orElseGet(() -> roleRepository.save(new Role("ADMIN")));
    }
}
