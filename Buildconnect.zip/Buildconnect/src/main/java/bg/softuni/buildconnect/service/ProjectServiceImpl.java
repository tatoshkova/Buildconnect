package bg.softuni.buildconnect.service;

import bg.softuni.buildconnect.dto.ProjectDTO;
import bg.softuni.buildconnect.entity.Project;
import bg.softuni.buildconnect.entity.User;
import bg.softuni.buildconnect.repository.ProjectRepository;
import bg.softuni.buildconnect.repository.UserRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;
    private final UserRepository userRepository;
    private final ApplicationEventPublisher eventPublisher;

    public ProjectServiceImpl(ProjectRepository projectRepository,
                              UserRepository userRepository,
                              ApplicationEventPublisher eventPublisher) {
        this.projectRepository = projectRepository;
        this.userRepository = userRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public List<ProjectDTO> getAllProjects() {
        return projectRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<ProjectDTO> getProjectById(Long id) {
        return projectRepository.findById(id).map(this::mapToDTO);
    }

    @Override
    public void createProject(ProjectDTO projectDTO) {
        User creator = userRepository.findByUsername(projectDTO.getCreatedByUsername())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        Project project = new Project();
        project.setTitle(projectDTO.getTitle());
        project.setDescription(projectDTO.getDescription());
        project.setAddress(projectDTO.getAddress());
        project.setStatus(projectDTO.getStatus());
        project.setCreatedBy(creator);

        projectRepository.save(project);

        eventPublisher.publishEvent(new ProjectCreatedEvent(this, project.getId(), creator.getUsername()));
    }

    @Override
    public void updateProject(Long id, ProjectDTO projectDTO) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Проект с ID " + id + " не съществува."));

        project.setTitle(projectDTO.getTitle());
        project.setDescription(projectDTO.getDescription());
        project.setAddress(projectDTO.getAddress());
        project.setStatus(projectDTO.getStatus());

        projectRepository.save(project);
    }

    @Override
    public void deleteProject(Long id) {
        projectRepository.deleteById(id);
    }

    @Override
    public long countAllProjects() {
        return projectRepository.count();
    }

    private ProjectDTO mapToDTO(Project project) {
        ProjectDTO dto = new ProjectDTO();
        dto.setId(project.getId());
        dto.setTitle(project.getTitle());
        dto.setDescription(project.getDescription());
        dto.setAddress(project.getAddress());
        dto.setStatus(project.getStatus());
        dto.setCreatedByUsername(project.getCreatedBy().getUsername());
        return dto;
    }
}
