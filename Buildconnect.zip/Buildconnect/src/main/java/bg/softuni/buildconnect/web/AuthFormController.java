package bg.softuni.buildconnect.web;

import bg.softuni.buildconnect.dto.RegistrationDTO;
import bg.softuni.buildconnect.dto.UserRegisterDTO;
import bg.softuni.buildconnect.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/auth")
public class AuthFormController {

    private final AuthService authService;

    public AuthFormController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        if (!model.containsAttribute("userRegisterDTO")) {
            model.addAttribute("userRegisterDTO", new UserRegisterDTO());
        }
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("userRegisterDTO") UserRegisterDTO userRegisterDTO,
                           BindingResult bindingResult,
                           Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("userRegisterDTO", userRegisterDTO);
            return "auth/register";
        }

        RegistrationDTO registrationDTO = new RegistrationDTO(
                userRegisterDTO.getUsername(),
                userRegisterDTO.getEmail(),
                userRegisterDTO.getPassword()
        );

        authService.register(registrationDTO);
        return "redirect:/auth/login";
    }
}
