package bg.softuni.buildconnect.service;

import bg.softuni.buildconnect.dto.DocumentDTO;
import bg.softuni.buildconnect.entity.Document;
import bg.softuni.buildconnect.entity.Project;
import bg.softuni.buildconnect.repository.DocumentRepository;
import bg.softuni.buildconnect.repository.ProjectRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;
    private final ProjectRepository projectRepository;

    public DocumentServiceImpl(DocumentRepository documentRepository, ProjectRepository projectRepository) {
        this.documentRepository = documentRepository;
        this.projectRepository = projectRepository;
    }

    @Override
    public List<DocumentDTO> getAllDocuments() {
        return documentRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<DocumentDTO> getDocumentById(Long id) {
        return documentRepository.findById(id).map(this::mapToDTO);
    }

    @Override
    public void saveDocument(DocumentDTO documentDTO) {
        Project project = projectRepository.findById(documentDTO.getProjectId())
                .orElseThrow(() -> new IllegalArgumentException("Project not found"));

        Document document = new Document();
        document.setName(documentDTO.getName());
        document.setFileUrl(documentDTO.getFileUrl());
        document.setProject(project);

        documentRepository.save(document);
    }

    @Override
    public void deleteDocument(Long id) {
        documentRepository.deleteById(id);
    }

    private DocumentDTO mapToDTO(Document document) {
        DocumentDTO dto = new DocumentDTO();
        dto.setId(document.getId());
        dto.setName(document.getName());
        dto.setFileUrl(document.getFileUrl());
        dto.setProjectId(document.getProject().getId());
        return dto;
    }
}
